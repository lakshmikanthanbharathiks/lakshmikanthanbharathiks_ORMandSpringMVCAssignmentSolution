package com.greatlearning.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.crm.entity.Customer;
import com.greatlearning.crm.service.CustomerService;

@Controller
public class WelcomeController {

	@Autowired
	private CustomerService customerService;

	@RequestMapping("/")
	public String showHome(Model model) {
		List<Customer> customers = customerService.findAllCustomer();
		System.out.println("data on customers" + customers);
		model.addAttribute("customers", customers);
		return "home";
	}

	@RequestMapping("/addform")
	public String addForm(Model model) {
		Customer customer = new Customer();
		model.addAttribute("customerObj", customer);
		model.addAttribute("mode", "Save");
		return "customer-form";

	}

	@PostMapping("/save")
	public String saveCustomer(@RequestParam(name = "id") int id, @RequestParam(name = "firstName") String firstName,
			@RequestParam(name = "lastName") String lastName, @RequestParam(name = "emailId") String emailId) {

		Customer customer = null;
		if (id == 0) {
			customer = new Customer(firstName, lastName, emailId);
			System.out.println(customer);
		} else {
			customer = customerService.findCustomer(id);
			customer.setEmailId(emailId);
			customer.setFirstName(firstName);
			customer.setLastName(lastName);
		}
		System.out.println("Customer at save" + customer);
		customerService.saveCustomer(customer);
		return "redirect:/";
	}

	@RequestMapping("/update")
	public String updateCustomer(@RequestParam(name = "id") int id, Model model) {
		Customer customer = customerService.findCustomer(id);
		System.out.println("found cuter" + customer);
		model.addAttribute("customerObj", customer);
		model.addAttribute("mode", "Update");
		return "customer-form";
	}

	@RequestMapping("/delete")
	public String deleteCustomer(@RequestParam(name = "id") int id) {
		customerService.deleteCustomer(id);
		return "redirect:/";
	}

}
